<?php
require_once '../models/config.php';
require_once '../models/BDD.php';

$db = new Database();
$conn = $db->getConnection();

$query = "SELECT * FROM mot_liaison";
$result = $conn->query($query);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Liste des Mots de Liaison</title>
    <link rel="stylesheet" href="../public/style.css?v=0">
</head>
<body>
    <?php include '../layouts/header.php'; ?>
    <h1>Liste des Mots de Liaison</h1>
    <table border="1">
        <thead>
            <tr>
                <th>ID</th>
                <th>Mot</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($row['id']) ?></td>
                    <td><?= htmlspecialchars($row['mot']) ?></td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
    <?php include '../layouts/footer.php'; ?>
</body>
</html>