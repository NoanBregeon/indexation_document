<?php
define('BASE_URL', '/PHP/indexation_document/'); // Remplacez '/' par le chemin de base si nécessaire
?>