<footer>
        <p>&copy; 2023 EasyIndex. Tous droits réservés.</p>
</footer>