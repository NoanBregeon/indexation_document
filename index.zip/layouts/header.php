<?php require_once '../models/BDD.php'; ?>
<a href="<?= BASE_URL ?>index.php">Retour à l'accueil</a>
<a href="<?= BASE_URL ?>views/mots_liaison.php">Mots de liaison</a>
<a href="<?= BASE_URL ?>views/textes.php">Textes</a>